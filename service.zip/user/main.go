package main

import (
	"github.com/micro/go-micro/util/log"
	"github.com/micro/go-micro"
	"iHomeProject/service/user/handler"

	user "iHomeProject/service/user/proto/user"
	"iHomeProject/service/user/model"
	"github.com/micro/go-micro/registry/consul"
)

func main() {
	model.InitRedis()
	model.InitDb()

	//初始化consul
	consulRegistry := consul.NewRegistry()

	// New Service
	service := micro.NewService(
		micro.Name("go.micro.srv.user"),
		micro.Version("latest"),
		micro.Registry(consulRegistry),
		micro.Address(":10086"),
	)

	// Initialise service
	service.Init()

	// Register Handler
	user.RegisterUserHandler(service.Server(), new(handler.User))

	// Run service
	if err := service.Run(); err != nil {
		log.Fatal(err)
	}
}
