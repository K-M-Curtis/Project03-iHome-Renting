package main

import (
	"github.com/micro/go-micro/util/log"
	"github.com/micro/go-micro"
	"iHomeProject/service/house/handler"

	house "iHomeProject/service/house/proto/house"
	"github.com/micro/go-micro/registry/consul"
	"iHomeProject/service/house/model"
)

func main() {
	consulReg := consul.NewRegistry()

	// New Service
	service := micro.NewService(
		micro.Name("go.micro.srv.house"),
		micro.Version("latest"),
		micro.Address(":8899"),
		micro.Registry(consulReg),
	)

	// Initialise service
	service.Init()
	model.InitDb()

	// Register Handler
	house.RegisterHouseHandler(service.Server(), new(handler.House))


	// Run service
	if err := service.Run(); err != nil {
		log.Fatal(err)
	}
}
