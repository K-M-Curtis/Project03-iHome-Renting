package conf

//数据库有关配置
const (
	//Mydql配置
	DbUser = "root"
	DbPwd = "123456"
	DbAddr = "127.0.0.1"
	DbPort = "3306"
	DbName = "ihome"

	//Redis配置
	RedisAddr = "192.168.245.139"
	RedisPort = "6379"

)
