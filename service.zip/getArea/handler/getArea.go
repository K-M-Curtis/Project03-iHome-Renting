package handler

import (
	"context"

	getArea "iHomeProject/service/getArea/proto/getArea"
	"iHomeProject/service/getArea/model"
	"iHomeProject/web/tool"
)

type GetArea struct{}

// Call is a single request handler called via client.Call or the generated client code
func (e *GetArea) Call(ctx context.Context, req *getArea.Request, rsp *getArea.Response) error {
	//相关的业务处理  获取地域信息
	areas,err := model.GetArea()
	//rpc如果返回err数据,就不再返回定义的数据
	if err!=nil{
		rsp.Errno = tool.RECODE_DBERR
		rsp.Errmsg = tool.RecodeText(tool.RECODE_DBERR)
		return nil
	}

	rsp.Errno = tool.RECODE_OK
	rsp.Errmsg = tool.RecodeText(tool.RECODE_OK)

	var areaObjs []*getArea.Area

	for _,v := range areas{
		var temp getArea.Area

		temp.Aid = int32(v.Id)
		temp.Aname = v.Name
		//得到单个对象之后,要把对象放到切片中
		areaObjs = append(areaObjs,&temp)

	}

	rsp.Data = areaObjs
	return nil
}

