package model

import (
	"encoding/json"
	"fmt"
	"github.com/gomodule/redigo/redis"
)

//获取地域信息的业务   微服务的项目
func GetArea()([]Area,error){
	//连接数据库,使用全局的连接池
	var areas []Area
	conn := RedisPool.Get()
	//从Redis中获取数据
	areaBuf,err:=redis.Bytes(conn.Do("get","area"))
	if len(areaBuf)==0{
		//从MySQL中获取数据
		err = GlobalDb.Find(&areas).Error

		//将数据打包程json格式,存入到redis中
		areaByte,_:=json.Marshal(areas)
		conn.Do("set","area",areaByte)

		fmt.Println("从MySQL中获取数据")
	}else{
		//从redis中直接获取数据,反序列化
		json.Unmarshal(areaBuf, &areas)

		fmt.Println("从redis中获取数据")
	}


	return areas,err
}
