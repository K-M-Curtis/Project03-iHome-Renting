package tool

import (
	"github.com/micro/go-micro"
	"github.com/micro/go-micro/registry/consul"
)

func GetMicroService()micro.Service{
	//调用服务端代码
	consulReg := consul.NewRegistry()
	return micro.NewService(micro.Registry(consulReg))

}
