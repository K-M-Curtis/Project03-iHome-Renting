package main

import(
	"github.com/gin-gonic/gin"
	"iHomeProject/web/model"
	"iHomeProject/web/controller"
	"github.com/gin-contrib/sessions/redis"
	"iHomeProject/service/user/conf"
	"github.com/gin-contrib/sessions"
	"fmt"
	"iHomeProject/web/tool"
	"time"
	"net/http"
)

//路由过滤器
func Filter(ctx *gin.Context){
	//登录校验
	session := sessions.Default(ctx)
	userName := session.Get("userName")
	resp := make(map[string]interface{})
	if userName == nil{
		resp["errno"]=tool.RECODE_SESSIONERR
		resp["errmsg"]=tool.RecodeText(tool.RECODE_SESSIONERR)
		ctx.JSON(http.StatusOK,resp)
		ctx.Abort()
		return 
	}
	
	//计算这个业务耗时
	fmt.Println("next之前打印",time.Now())
	
	//执行函数
	ctx.Next()
	
	fmt.Println("next之后打印")
}

//gin的核心知识点
func MiddleTest()(func(*gin.Context)){
	return func (context *gin.Context){
	}
}

func main(){
	//初始化数据库表
	model.InitDb()
	//初始化Redis
	model.InitRedis()

	//初始化路由
	router := gin.Default()

	//路由的匹配
	/*router.GET()*/
	router.Static("/home","view")

	/*
	需要和前端工程师沟通,确定错误码数据
	http协议自带的状态码

	前端工程师根据错误码做相应处理
	*/

	//需要初始化session容器 	redis连接池
	store,_:=redis.NewStore(10,"tcp",conf.RedisAddr+":"+conf.RedisPort,"",[]byte("SESSION"))

	//设置生成session的cookie的属性
	//store.Options(sessions.Options{MaxAge:0,})

	//使用中间件函数  cookie的name值
	router.Use(sessions.Sessions("mysession",store))

	//获取到请求的路由	/api/v1.0/areas  分组提高代码复用
	r1 := router.Group("/api/v1.0")
	{
		r1.GET("/areas",controller.GetArea)
		//r1.GET("/session",controller.GetSession)
		r1.GET("/imagecode/:uuid",controller.GetImg)
		r1.GET("/smscode/:phone",controller.SendSms)
		r1.POST("/users",controller.PostRet)


		//登录业务   路由过滤器   中间件
		r1.Use(sessions.Sessions("mysession",store))
		r1.POST("/sessions",controller.PostLogin)
		r1.GET("/session",controller.GetSession)
		r1.Use(Filter)
		r1.DELETE("/session",controller.DeleteSession)
		r1.GET("/user",controller.GetUserInfo)
		r1.PUT("/user/name",controller.PutUserInfo)

		r1.POST("/user/avatar",controller.PostAvatar)
		r1.POST("/user/auth",controller.PutUserAuth)
		r1.GET("/user/auth",controller.GetUserInfo)

		//获取已发布房源信息
		r1.GET("/user/houses",controller.GetUserHouse)
		//发布房源
		r1.POST("/houses",controller.PostHouse)
		//添加房源图片
		r1.POST("/houses/:id/images",controller.PostHouseImage)
		//展示房屋详情
		r1.GET("/houses/:id",controller.GetHouseInfo)
		//展示首页轮播图
		r1.GET("/house/index",controller.GetIndex)
		//搜索房屋
		r1.GET("/houses",controller.GetHouses)
		//下订单
		r1.POST("/orders",controller.PostOrders)
		//获取订单
		r1.GET("/user/orders",controller.GetUserOrder)
		//同意或拒绝订单
		r1.PUT("/orders/:id/status",controller.PutOrders)
		//更新评论
		r1.PUT("/orders/:id/comment",controller.PutComment)
	}


	//路由使用中间件 gin中的session默认是生效时间是一个月
	router.Use(sessions.Sessions("mysession",store))
	
	//使用路由的时候就可以使用session中间件了
	router.GET("/session",func(context *gin.Context){
		//初始化session对象
		se := sessions.Default(context)
		//设置session的时候除了set函数之外,必须调用save
		se.Set("test","MYTEST")
		se.Save()
		context.Writer.WriteString("设置session")
	})

	/*//secure  	设置为true之后不让访问
	router.GET("/cookie",func(context *gin.Context){
		context.SetCookie("mytest","COOKIE",0,"","",false,true)
		value,err:=context.Cookie("mytest")
		fmt.Println(value,err)
		context.Writer.WriteString(value)

		//存储session
		//初始化session对象
		s:=sessions.Default(context)
		s.Set("mysession","123456")

		//在session使用中,set和delete都需要调用save函数
		s.Save()

		name := s.Get("mysession")
		fmt.Println(name)
		context.Writer.WriteString(name.(string))
	})*/


	//让服务跑起来
	router.Run(":8080")
}
