package controller

import (
	"github.com/gin-gonic/gin"

	"fmt"
	"net/http"
	"github.com/micro/go-micro/registry/consul"
	"github.com/micro/go-micro"
	"context"
	"iHomeProject/web/tool"
	"image/png"
	"github.com/afocus/captcha"
	"encoding/json"
	getArea "iHomeProject/web/proto/getArea"
	user "iHomeProject/web/proto/user"
	houseMicro "iHomeProject/web/proto/house"
	orderMicro "iHomeProject/web/proto/userOrder"
	"github.com/gin-contrib/sessions"
	"path"
)

//获取地区信息
func GetArea(ctx *gin.Context){
	//处理具体业务 数据库中存储地域信息
	/*areas,err := model.GetArea()

	resp := make(map[string]interface{})
	if err!=nil{
		resp["errno"] = tool.RECODE_DBERR
		resp["errmsg"] = tool.RecodeText(tool.RECODE_DBERR)
		ctx.JSON(http.StatusOK,resp)
		return
	}

	resp["errno"] = tool.RECODE_OK
	resp["errmsg"] = tool.RecodeText(tool.RECODE_OK)
	resp["data"] = areas
	ctx.JSON(http.StatusOK,resp)*/

	//调用服务的接口  服务端和web端通信数据格式得一致  protobuf

	//初始化micro的client对象
	consulRegistry := consul.NewRegistry()

	microService := micro.NewService(
		micro.Registry(consulRegistry),
	)

	//初始化客户端
	microClient := getArea.NewGetAreaService("go.micro.srv.getArea",microService.Client())

	//调用远程方法
	resp,err := microClient.Call(context.TODO(),&getArea.Request{})
	if err != nil{
		fmt.Println(err)
	}

	ctx.JSON(http.StatusOK,resp)
}

//获取session信息
func GetSession(ctx *gin.Context){
	resp := make(map[string]interface{})
	/*
	resp["errno"]=tool.RECODE_SESSIONERR
	resp["errmsg"]=tool.RecodeText(tool.RECODE_SESSIONERR)
	*/

	//获取session数据
	//初始化session对象
	s:=sessions.Default(ctx)
	userName := s.Get("userName")
	if userName == nil{
		resp["errno"] = tool.RECODE_SESSIONERR
		resp["errmsg"] = tool.RecodeText(tool.RECODE_SESSIONERR)
	}else{
		resp["errno"] = tool.RECODE_OK
		resp["errmsg"] = tool.RecodeText(tool.RECODE_OK)

		temp := make(map[string]string)
		temp["name"] = userName.(string)
		resp["data"] = temp

	}

	//返回数据给前端
	ctx.JSON(http.StatusOK,resp)
}

//获取验证码图片方法
func GetImg(ctx *gin.Context){
	uuid := ctx.Param("uuid")

	/*//获取到uuid,生成图片,然后传递到页面上

	cap := captcha.New()
	//设置字符集   路径是相对于main.go的路径
	cap.SetFont("conf/comic.ttf")

	//设置图片的大小
	cap.SetSize(128,64)

	//设置字体颜色
	cap.SetFrontColor(color.RGBA{255,255,0,255})

	//设置背景色
	cap.SetBkgColor(color.RGBA{0,0,255,255})

	//设置混淆
	cap.SetDisturbance(captcha.HIGH)

	//生成图片
	img,str := cap.Create(6,captcha.ALL)
	fmt.Println(str)

	png.Encode(ctx.Writer,img)*/

	//调用服务端代码
	microService := tool.GetMicroService()

	//初始化客户端  密码本
	microClient := user.NewUserService("go.micro.srv.user",microService.Client())

	resp,_:=microClient.GetImgCode(context.TODO(),&user.Request{Uuid:uuid})

	var img captcha.Image
	json.Unmarshal(resp.Img,&img)
	png.Encode(ctx.Writer,img)
}

//发送短信
func SendSms(ctx *gin.Context){
	//获取前段传递的数据
	phone := ctx.Param("phone")
	//ctx.DefaultQuery("text","1234")
	text := ctx.Query("text")
	id := ctx.Query("id")

	//校验数据
	if phone == "" || text == "" || id == ""{
		fmt.Println("获取前端数据错误")
		return
	}

	//操作数据
	microService := tool.GetMicroService()
	//获取客户端
	microClient := user.NewUserService("go.micro.srv.user",microService.Client())

	//调用远程服务
	resp,_ := microClient.SendSms(context.TODO(),&user.MsgReq{
		Phone:phone,
		Text:text,
		Uuid:id,
	})

	ctx.JSON(http.StatusOK,resp)
}

type Reg struct {
	Mobile string `json:"mobile"`
	Password string `json:"password"`
	SmsCode string `json:"sms_code"`
}

//注册业务
func PostRet(ctx *gin.Context){
	//获取数据
	/*mobile := ctx.PostForm("mobile")
	pwd := ctx.PostForm("password")
	smsCode := ctx.PostForm("sms_code")
	*/
	var reg Reg
	err := ctx.Bind(&reg)
	//校验数据
	if err != nil{
		fmt.Println("获取数据错误",err)
		return
	}

	//处理数据 	为服务中实现
	//初始化micro服务
	microService := tool.GetMicroService()

	//初始化客户端
	microClient := user.NewUserService("go.micro.srv.user",microService.Client())

	//调用远程函数
	resp,_:=microClient.Register(context.TODO(),&user.RegReq{
		Mobile:reg.Mobile,
		Password:reg.Password,
		SmsCode:reg.SmsCode,
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

//登录
func PostLogin(ctx *gin.Context){
	//获取数据
	var reg Reg
	err := ctx.Bind(&reg)
	//校验数据
	if err != nil{
		fmt.Println("获取前端数据错误",err)
		return
	}
	//处理数据,服务端处理
	microService := tool.GetMicroService()

	//注册client
	microClient := user.NewUserService("go.micro.srv.user",microService.Client())

	//调用远程服务
	resp,_ := microClient.Login(context.TODO(),&user.RegReq{
		Mobile:reg.Mobile,
		Password:reg.Password,
	})

	//添加session 添加用户名到session
	//初始化session对象
	s:=sessions.Default(ctx)
	s.Set("userName",resp.UserName)
	s.Save()


	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

//退出登录
func DeleteSession(ctx *gin.Context){
	//删除session
	session := sessions.Default(ctx)
	
	session.Delete("userName")
	err := session.Save()
	
	fmt.Println("控制器函数执行...")
	
	resp := make(map[string]interface{})
	defer ctx.JSON(http.StatusOK,resp)
	if err != nil{
		resp["errno"]=tool.RECODE_DATAERR
		resp["errmsg"]=tool.RecodeText(tool.RECODE_DATAERR)
		return 
	}
	resp["errno"]=tool.RECODE_OK
	resp["errmsg"]=tool.RecodeText(tool.RECODE_OK)
}


//获取用户信息
func GetUserInfo(ctx *gin.Context){
	//获取session数据
	session := sessions.Default(ctx)
	userName := session.Get("userName")

	/*userInfo := model.GetUserInfo(userName.(string))

	resp:=make(map[string]interface{})
	resp["errno"] = tool.RECODE_OK
	resp["errmsg"] = tool.RecodeText(tool.RECODE_OK)
	resp["data"] = &userInfo*/


	//处理数据,服务端处理
	microService := tool.GetMicroService()

	//注册服务
	microClient := user.NewUserService("go.micro.srv.user",microService.Client())
	
	//调用远程服务
	resp,_ := microClient.MicroGetUser(context.TODO(),&user.GetUser{Name:userName.(string)})
	
	ctx.JSON(http.StatusOK,resp)
}

type UpdateUsr struct{
	Name string `json:"name"`
}

//更新用户名
func PutUserInfo(ctx *gin.Context){
	//获取数据
	var nameData UpdateUsr 
	err := ctx.Bind(&nameData)
	//校验数据
	if err != nil{
		fmt.Println("获取数据错误")
		return 
	}
	
	//从session中获取原有的用户名
	session := sessions.Default(ctx)
	userName :=  session.Get("userName")
	//处理数据,服务端处理
	microService := tool.GetMicroService()

	//注册服务
	microClient := user.NewUserService("go.micro.srv.user",microService.Client())
	
	//调用远程服务
	resp,_:=microClient.UpdateUserName(context.TODO(),&user.UpdateReq{NewName:nameData.Name,OldName:userName.(string)})
	
	//更新session数据
	if resp.Errno == tool.RECODE_OK{
		//更新成功，session中的用户名也要更新一下
		session.Set("userName", nameData.Name)
		session.Save()
	}
	
	ctx.JSON(http.StatusOK,resp)
}

//上传用户头像
func PostAvatar(ctx *gin.Context){
	//获取数据
	fileHeader,err := ctx.FormFile("avatar")

	//检验数据
	if err != nil{
		fmt.Println("文件上传失败")
		return
	}

	//三种校验 大小,类型,防止重名
	if fileHeader.Size > 500000000{
		fmt.Println("文件过大,请重新选择")
		return
	}

	fileExt := path.Ext(fileHeader.Filename)
	if fileExt != ".png" && fileExt != ".jpg"{
		fmt.Println("文件类型错误,请重新选择")
		return
	}

	//只读 的文件指针  处理数据
	file,_ := fileHeader.Open()
	buf := make([]byte,fileHeader.Size)
	file.Read(buf)

	/*f,_ := os.Create(fileHeader.Filename)
	f.Write(buf)*/

	/*fdfsClient,_:=fdfs_client.NewFdfsClient("/etc/fdfs/client.conf")
	//fdfsClient.UploadByFilename()
	fdfsResp,_ := fdfsClient.UploadByBuffer(buf,fileExt[1:])
	fmt.Println("上传文件到fastdfs的组名为", fdfsResp.GroupName,"凭证为",fdfsResp.RemoteFileId)*/

	//获取用户名
	session := sessions.Default(ctx)
	userName := session.Get("userName")

	//处理数据
	microClient := user.NewUserService("go.micro.srv.user",tool.GetMicroService().Client())
	//调用远程函数
	resp,_:=microClient.UploadAvatar(context.TODO(),&user.UploadReq{
		UserName:userName.(string),
		Avatar:buf,
		FileExt:fileExt,
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

type AuthUsr struct{
	IdCard string `json:"id_card"`
	RealName string `json:"real_name"`
}

func PutUserAuth(ctx *gin.Context){
	//获取数据
	var auth AuthUsr
	err := ctx.Bind(&auth)

	//校验数据
	if err != nil{
		fmt.Println("获取数据错误",err)
		return
	}

	session := sessions.Default(ctx)
	userName := session.Get("userName")

	//处理数据
	microClient := user.NewUserService("go.micro.srv.user",tool.GetMicroService().Client())

	resp,_ := microClient.AuthUpdate(context.TODO(),&user.AuthReq{
		UserName:userName.(string),
		RealName:auth.RealName,
		IdCard:auth.IdCard,
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

//获取已发布房源信息  假数据
func GetUserHouse(ctx *gin.Context){
	/*resp:=make(map[string]interface{})

	resp["errno"] = tool.RECODE_OK
	resp["errmsg"] = tool.RecodeText(tool.RECODE_OK)
	resp["data"] = ""
	ctx.JSON(http.StatusOK,resp)*/

	//获取用户名
	userName := sessions.Default(ctx).Get("userName")

	//测试一对多查询
	//有用户名
	/*var userInfo model.User
	if err := model.GlobalDb.Where("name = ?",userName).Find(&userInfo).Error;err!=nil{
		fmt.Println("获取当前用户的信息错误",err)
	}
	//房源信息　一对多查询
	var house []model.House

	model.GlobalDb.Model(&userInfo).Related(&house)
	fmt.Println("111111",house)*/

	microClient := houseMicro.NewHouseService("go.micro.srv.house",tool.GetMicroService().Client())
	//调用远程服务
	resp,_ := microClient.GetHouseInfo(context.TODO(),&houseMicro.GetReq{UserName:userName.(string)})


	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

type HouseUsr struct{
	Acreage string 	`json:"acreage"`
	Address string  `json:"address"`
	AreaId string   	`json:"area_id"`
	Beds string 	`json:"beds"`
	Capacity string	`json:"capacity"`
	Deposit string 	`json:"deposit"`
	Facility []string  `json:"facility"`
	MaxDays string		`json:"max_days"`
	MinDays string 	`json:"min_days"`
	Price   string 	`json:"price"`
	RoomCount string	`json:"room_count"`
	Title string 	`json:"title"`
	Unit string 	`json:"unit"`
}

//发布房源
func PostHouse(ctx *gin.Context){
	//获取数据   bind数据的时候不带自动转换   c.getInt()
	var house HouseUsr
	err := ctx.Bind(&house)

	//校验数据
	if err != nil{
		fmt.Println("获取数据错误",err)
		return
	}

	//获取用户名
	userName := sessions.Default(ctx).Get("userName")

	//处理数据 服务端处理
	microClient := houseMicro.NewHouseService("go.micro.srv.house",tool.GetMicroService().Client())

	//调用远程服务
	resp,_:=microClient.PubHouse(context.TODO(),&houseMicro.Request{
		Acreage:house.Acreage,
		Address:house.Address,
		AreaId:house.AreaId,
		Beds:house.Beds,
		Capacity:house.Capacity,
		Deposit:house.Deposit,
		Facility:house.Facility,
		MaxDays:house.MaxDays,
		MinDays:house.MinDays,
		Price:house.Price,
		RoomCount:house.RoomCount,
		Title:house.Title,
		Unit:house.Unit,
		UserName:userName.(string),
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

//上传房屋图片
func PostHouseImage(ctx *gin.Context){
	//获取数据
	houseId := ctx.Param("id")
	fileHeader,err := ctx.FormFile("house_image")
	//校验数据
	if houseId == "" || err != nil{
		fmt.Println("传入数据不完整",err)
		return
	}

	//三种校验 大小,类型,防止重名
	if fileHeader.Size > 50000000{
		fmt.Println("文件过大,请重新选择")
		return
	}

	fileExt := path.Ext(fileHeader.Filename)
	if fileExt != ".png" && fileExt != ".jpg"{
		fmt.Println("文件类型错误,请重新选择")
		return
	}

	//获取文件切片
	file,_:=fileHeader.Open()
	buf := make([]byte,fileHeader.Size)
	file.Read(buf)

	//处理数据，服务中实现
	microClient := houseMicro.NewHouseService("go.micro.srv.house",tool.GetMicroService().Client())
	//调用服务
	resp,_:=microClient.UploadHouseImg(context.TODO(),&houseMicro.ImgReq{
		HouseId:houseId,
		ImgData:buf,
		FileExt:fileExt,
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

//获取房屋详情
func GetHouseInfo(ctx *gin.Context){
	//获取数据
	houseId := ctx.Param("id")
	//校验数据
	if houseId == ""{
		fmt.Println("获取数据错误")
		return
	}
	userName := sessions.Default(ctx).Get("userName")

	//处理数据
	microClient := houseMicro.NewHouseService("go.micro.srv.house",tool.GetMicroService().Client())
	//调用远程服务
	resp,_ := microClient.GetHouseDetail(context.TODO(),&houseMicro.DetailReq{
		HouseId:houseId,
		UserName:userName.(string),
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

func GetIndex(ctx *gin.Context){
	//处理数据
	microClient := houseMicro.NewHouseService("go.micro.srv.house",tool.GetMicroService().Client())
	//调用远程服务
	resp,_ := microClient.GetIndexHouse(context.TODO(),&houseMicro.IndexReq{})


	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

//搜索房屋
func GetHouses(ctx *gin.Context){
	//获取数据
	aid := ctx.Query("aid")
	sd := ctx.Query("sd")
	ed := ctx.Query("ed")
	sk := ctx.Query("sk")

	//校验数据
	if aid == "" || sd == "" || ed == "" || sk == ""{
		fmt.Println("传入的数据不完整")
		return
	}

	//处理数据   服务端  把字符串转换为时间格式,使用函数time.Parse()  第一个参数是转换模板,需要转换的二字符串,两者格式一致
	/*sdTime ,_:=time.Parse("2006-01-02 15:04:05",sd+" 00:00:00")
	edTime,_ := time.Parse("2006-01-02",ed)*/

	/*sdTime,_ :=time.Parse("2006-01-02",sd)
	edTime,_ := time.Parse("2006-01-02",ed)
	d := edTime.Sub(sdTime)
	fmt.Println(d.Hours())*/

	microClient := houseMicro.NewHouseService("go.micro.srv.house",tool.GetMicroService().Client())
	//调用远程服务
	resp,_ := microClient.SearchHouse(context.TODO(),&houseMicro.SearchReq{
		Aid:aid,
		Sd:sd,
		Ed:ed,
		Sk:sk,
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)

}

type OrderUser struct {
	EndDate 	string `json:"end_date"`
	HouseId		string `json:"house_id"`
	StartDate 	string `json:"start_date"`
}

//下订单
func PostOrders(ctx *gin.Context){
	//获取数据
	var order OrderUser
	err := ctx.Bind(&order)

	//校验数据
	if err != nil{
		fmt.Println("获取数据错误",err)
		return
	}
	//获取用户名
	userName := sessions.Default(ctx).Get("userName")

	//处理数据
	microClient := orderMicro.NewUserOrderService("go.micro.srv.userOrder",tool.GetMicroService().Client())
	//调用服务
	resp,_:=microClient.CreateOrder(context.TODO(),&orderMicro.Request{
		StartDate:order.StartDate,
		EndDate:order.EndDate,
		HouseId:order.HouseId,
		UserName:userName.(string),
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

//获取订单信息
func GetUserOrder(ctx *gin.Context){
	//获取Get请求传参
	role := ctx.Query("role")
	//校验数据
	if role == ""{
		fmt.Println("获取数据失败")
		return
	}

	//处理数据
	microClient := orderMicro.NewUserOrderService("go.micro.srv.userOrder",tool.GetMicroService().Client())
	//调用远程服务
	resp,_:=microClient.GetOrderInfo(context.TODO(),&orderMicro.GetReq{
		Role:role,
		UserName:sessions.Default(ctx).Get("userName").(string),
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}

type StatusUser struct {
	Action string `json:"action"`
	Reason string `json:"reason"`
}

//更新订单状态
func PutOrders(ctx *gin.Context){
	//获取数据
	id := ctx.Param("id")
	var statusUser StatusUser
	err := ctx.Bind(&statusUser)

	//校验数据
	if err != nil || id == "" {
		fmt.Println("获取数据错误",err)
		return
	}

	//处理数据
	microClient := orderMicro.NewUserOrderService("go.micro.srv.userOrder",tool.GetMicroService().Client())
	//调用远程服务
	resp,_:=microClient.UpdateStatus(context.TODO(),&orderMicro.UpdateReq{
		Action:statusUser.Action,
		Reason:statusUser.Reason,
		Id:id,
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}


type CommentOrder struct {
	Comment string `json:"comment"`
	//UserId uint `json:user_id`
}

//更新评论
func PutComment(ctx *gin.Context){
	//获取数据
	id := ctx.Param("id")
	var commentOrder CommentOrder
	err := ctx.Bind(&commentOrder)
	//校验数据
	if err != nil || id == ""{
		fmt.Println("获取评论数据错误",err)
		return
	}

	//处理数据
	microClient := orderMicro.NewUserOrderService("go.micro.srv.userOrder",tool.GetMicroService().Client())
	//调用远程服务
	resp,_ := microClient.UpdateComment(context.TODO(),&orderMicro.CommentReq{
		Comment:commentOrder.Comment,
		Id:id,
	})

	//返回数据
	ctx.JSON(http.StatusOK,resp)
}
