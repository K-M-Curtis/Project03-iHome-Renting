package main

import (
	"github.com/afocus/captcha"
	"image/color"
	"github.com/gin-gonic/gin"
	"image/png"
	"fmt"
)

func main(){
	//初始化一个对象
	cap := captcha.New()
	//设置字符集
	cap.SetFont("comic.ttf")

	//设置图片大小
	cap.SetSize(128, 64)

	//设置字体颜色
	cap.SetFrontColor(color.RGBA{255,0,0,255},color.RGBA{0,255,0,0})

	//设置背景颜色		字体颜色和背景颜色
	cap.SetBkgColor(color.RGBA{0,0,255,255},color.RGBA{100,30,155,255})

	//设置混淆
	cap.SetDisturbance(captcha.HIGH)

	//设置生成几个字符
/*	img,str := cap.Create(6,captcha.NUM)
	fmt.Println(str)*/

	router  := gin.Default()
	router.GET("/img",func(context *gin.Context){
		//写一个自己输入的验证按
		img,str := cap.Create(6,captcha.ALL)
		//cap.CreateCustom("123456")
		fmt.Println(str)
		png.Encode(context.Writer,img)
	})

	router.Run(":10010")
}

