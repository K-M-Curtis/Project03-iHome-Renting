package model


import (
	"encoding/json"
	"fmt"
	"github.com/gomodule/redigo/redis"
	"strings"
	"crypto/md5"
	"encoding/hex"
)


//获取地域信息的业务   微服务的项目
func GetArea()([]Area,error){
	//连接数据库  使用全局的连接池
	var areas []Area
	conn := RedisPool.Get()
	//从redis中获取数据
	areaBuf ,err:= redis.Bytes(conn.Do("get","area"))
	if len(areaBuf) == 0{
		//从mysql中获取数据
		err = GlobalDb.Find(&areas).Error

		//将数据打包程json格式,存入redis中
		areaByte,_ :=json.Marshal(areas)

		conn.Do("set","area",areaByte)

		fmt.Println("从mysql中获取的数据")
	}else {
		//从redis中获取数据
		//直接反序列化
		json.Unmarshal(areaBuf,&areas)

		fmt.Println("从redis中获取数据")
	}
	return areas,err
}

//存储图片验证码
func SaveImgCode(uuid,code string){
	//获取链接
	conn := RedisPool.Get()
	defer conn.Close()

	code = strings.ToLower(code)

	conn.Do("setex",uuid,60*5,code)
}

//校验图片验证码是否正确
func CheckImgCode(uuid,text string)bool{
	//获取redis链接
	conn := RedisPool.Get()

	//根据uuid获取存入的图片验证码
	result,_ :=redis.String(conn.Do("get",uuid))

	text = strings.ToLower(text)

	if result == text{
		return true
	}else {
		return false
	}
}

//存储用户短信验证码
func SaveSmsCode(phone,rndCode string){
	//获取redis链接
	conn := RedisPool.Get()
	//存储短信验证码
	conn.Do("setex",phone+"_code",5*60,rndCode)
}


//插入用户数据到mysql
func Register(mobile,pwd string)error{
	//插入数据
	var user User
	user.Name = mobile
	user.Mobile = mobile

	//密码是密文存储  md5
	m := md5.New()
	m.Write([]byte(pwd))
	encStr := hex.EncodeToString(m.Sum(nil))

	user.Password_hash = encStr

	return GlobalDb.Create(&user).Error
}

//校验短信验码是否正确
func CheckSmsCode(mobile,code string)bool{
	//获取redis链接
	conn := RedisPool.Get()

	//获取redis中存储的验证码
	codeStr ,_ := redis.String(conn.Do("get",mobile+"_code"))
	/*if codeStr == code {
		return true
	}else {
		return false
	}*/

	return codeStr == code
}

//登录业务
func Login(mobile,pwd string)string{

	//hash加密
	m := md5.New()
	m.Write([]byte(pwd))
	hashPwd := hex.EncodeToString(m.Sum(nil))

	/*GlobalDb.Model(new(User)).Where("mobile = ?",mobile).
		Where("password_hash = ?",hashPwd).Count(&num)*/

	var user User
	GlobalDb.Where("mobile = ?",mobile).Where("password_hash = ?",hashPwd).Select("name").Find(&user)

	/*if num == 1 {
		return true
	}else {
		return false
	}*/

	return user.Name
}

//获取用户信息
func GetUserInfo(userName string)(User,error){
	//连接数据库
	var user User
	err := GlobalDb.Where("name = ?",userName).Find(&user).Error
	return user,err
}

//更新用户名
func UpdateUserName(oldName,newName string)error{
	//更新  链式调用
	return GlobalDb.Model(new(User)).Where("name = ?",oldName).Update("name",newName).Error
}

//存储用户头像   更新
func SaveUserAvatar(userName,avatarUrl string)error{
	return GlobalDb.Model(new(User)).Where("name = ?",userName).Update("avatar_url",avatarUrl).Error
}

//存储用户真实姓名
func SaveRealName(userName,realName,idCard string)error{
	return GlobalDb.Model(new(User)).Where("name = ?",userName).
		Updates(map[string]interface{}{"real_name":realName,"id_card":idCard}).Error
}


