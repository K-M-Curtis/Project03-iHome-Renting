package handler

import (
	"context"

	user "iHomeProject/service/user/proto/user"
	"github.com/afocus/captcha"
	"image/color"
	"encoding/json"
	"iHomeProject/web/tool"
	"iHomeProject/service/user/model"
	"github.com/aliyun/alibaba-cloud-sdk-go/services/dysmsapi"
	"fmt"
	"math/rand"
	"time"
	"github.com/weilaihui/fdfs_client"
)

type User struct{}

//获取字符验证码
func (e *User) GetImgCode(ctx context.Context,req *user.Request,rsp *user.Response)error{
	//生成图片
	cap := captcha.New()
	//设置字符集   路径是相对于main.go的路径
	cap.SetFont("conf/comic.ttf")
	//设置图片的大小
	cap.SetSize(128,64)
	//设置字体颜色
	cap.SetFrontColor(color.RGBA{255,255,0,255})
	//设置背景色
	cap.SetBkgColor(color.RGBA{0,0,255,255})
	//设置混淆
	cap.SetDisturbance(captcha.HIGH)
	//生成图片
	img,str := cap.Create(6,captcha.ALL)
	//存储图片验证码  redis
	model.SaveImgCode(req.Uuid,str)
	//传递给web端  需要给对象指针序列化
	imgBuf,_ := json.Marshal(img)

	rsp.Errno = tool.RECODE_OK
	rsp.Errmsg = tool.RecodeText(tool.RECODE_OK)
	rsp.Img = imgBuf
	return nil
}

//发送短信函数
func (e *User)SendSms(ctx context.Context,req *user.MsgReq,resp*user.Response)error{
	//需要先检验图片验证码输入是否正确
	if model.CheckImgCode(req.Uuid,req.Text){
		client,_:=dysmsapi.NewClientWithAccessKey("cn-hangzhou","LTAI4Fjk6GGRrL1gzDatcLZZ","8GRQB48IEKg0Nht2JO0189kAzzBbDD")

		request := dysmsapi.CreateSendSmsRequest()
		request.Scheme = "https"
		request.Domain = "dysmsapi.aliyuncs.com"
		request.PhoneNumbers = req.Phone
		request.SignName = "北京5期区块链"
		request.TemplateCode = "SMS_176375357"

		//生成随机验证码   时间格式转为时间戳
		rnd := rand.New(rand.NewSource(time.Now().Unix()))
		//获取6位随机数
		rndCode := fmt.Sprintf("%06d",rnd.Int31n(1000000))
		request.TemplateParam = "{\"code\":"+rndCode+"}"

		response,_:=client.SendSms(request)
		if response.IsSuccess(){
			resp.Errno = tool.RECODE_OK
			resp.Errmsg = tool.RecodeText(tool.RECODE_OK)
			//短信发送成功需要存储短信验证码  redis有时效性
			model.SaveSmsCode(req.Phone,rndCode)
		}else{
			resp.Errno = tool.RECODE_SMSERR
			resp.Errmsg = tool.RecodeText(tool.RECODE_SMSERR)
		}
	}else{
		resp.Errno = tool.RECODE_SMSERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_SMSERR)
	}

	return nil
}

//注册业务
func (e *User)Register(ctx context.Context,req *user.RegReq,resp *user.Response)error{
	//校验短信验证码是否正确  验证码在redis中存储
	if model.CheckSmsCode(req.Mobile,req.SmsCode){
		//注册处理  把数据插入到数据库中
		err:=model.Register(req.Mobile,req.Password)
		if err != nil{
			resp.Errno = tool.RECODE_USERONERR
			resp.Errmsg = tool.RecodeText(tool.RECODE_USERONERR)
		}else{
			resp.Errno = tool.RECODE_OK
			resp.Errmsg = tool.RecodeText(tool.RECODE_OK)
		}
	}else{
		resp.Errno = tool.RECODE_SMSERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_SMSERR)
	}

	return nil
}

//登录业务
func (e *User)Login(ctx context.Context,req *user.RegReq,resp *user.Response)error{
	//获取前端数据,然后校验
	userName := model.Login(req.Mobile,req.Password)
	if userName != ""{
		resp.Errno = tool.RECODE_OK
		resp.Errmsg = tool.RecodeText(tool.RECODE_OK)
		resp.UserName = userName
	}else{
		resp.Errno = tool.RECODE_LOGINERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_LOGINERR)
	}

	return nil
}

//获取用户信息
func (e *User) MicroGetUser(ctx context.Context,req *user.GetUser, resp *user.Resp)error{
	myUser,err := model.GetUserInfo(req.Name)
	if err != nil{
		resp.Errno = tool.RECODE_USERERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_USERERR)
		return err
	}
	resp.Errno = tool.RECODE_OK
	resp.Errmsg = tool.RecodeText(tool.RECODE_OK)

	//获取一个结构体对象
	var userInfo user.UserInfo
	userInfo.UserId = int32(myUser.ID)
	userInfo.Name = myUser.Name
	userInfo.Mobile = myUser.Mobile
	userInfo.RealName = myUser.Real_name
	userInfo.IdCard = myUser.Id_card
	userInfo.AvatarUrl = "http://192.168.245.139:8888/"+myUser.Avatar_url

	resp.Data = &userInfo

	return nil
}

//更新用户名
func (e *User) UpdateUserName(ctx context.Context,req *user.UpdateReq, resp *user.UpdateResp)error{
	//根据传递过来的用户名更新数据中新的用户名
	err := model.UpdateUserName(req.OldName,req.NewName)
	if err != nil{
		fmt.Println("更新失败",err)
		resp.Errno = tool.RECODE_DATAERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_DATAERR)
		
		//micro规定如果有错误,服务端只给客户端返回错误信息,不返回resp,如果没有错误,就返回resp
		return nil
	}
	
	resp.Errno = tool.RECODE_OK
	resp.Errmsg = tool.RecodeText(tool.RECODE_OK)
	var nameData user.NameData
	nameData.Name = req.NewName
	
	resp.Data = &nameData
	return nil
}

func (e *User) UploadAvatar(ctx context.Context,req *user.UploadReq, resp *user.UploadResp)error {
	//存入到fastdfs中
	fClient,_ := fdfs_client.NewFdfsClient("/etc/fdfs/client.conf")
	//上传文件到fdfs
	fdfsResp,err := fClient.UploadByBuffer(req.Avatar,req.FileExt[1:])
	if err!=nil{
		fmt.Println("上传头像错误",err)
		resp.Errno = tool.RECODE_DATAERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_DATAERR)
		return nil
	}
	fmt.Println("上传文件到fastdfs的组名为", fdfsResp.GroupName,"凭证为",fdfsResp.RemoteFileId)
	//把存储凭证写入数据库
	err = model.SaveUserAvatar(req.UserName,fdfsResp.RemoteFileId)

	if err != nil{
		fmt.Println("上传头像失败",err)
		resp.Errno = tool.RECODE_DBERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_DBERR)
		return nil
	}

	resp.Errno = tool.RECODE_OK
	resp.Errmsg = tool.RecodeText(tool.RECODE_OK)

	var uploadData user.UploadData
	uploadData.AvatarUrl = "http://192.168.245.139:8888/" + fdfsResp.RemoteFileId
	resp.Data = &uploadData
	return nil
}

func (e *User) AuthUpdate(ctx context.Context,req *user.AuthReq, resp *user.AuthResp)error{
	//调用接口校验realName 和idcard是否匹配

	//存储真实姓名和身份证
	err := model.SaveRealName(req.UserName,req.RealName,req.IdCard)
	if err != nil{
		resp.Errno = tool.RECODE_DBERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_DBERR)
		return nil
	}

	resp.Errno = tool.RECODE_OK
	resp.Errmsg = tool.RecodeText(tool.RECODE_OK)

	return nil
}
