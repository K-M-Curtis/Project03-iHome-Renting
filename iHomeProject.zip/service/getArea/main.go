package main

import (
	"github.com/micro/go-micro/util/log"
	"github.com/micro/go-micro"
	"iHomeProject/service/getArea/handler"

	getArea "iHomeProject/service/getArea/proto/getArea"
	"iHomeProject/service/getArea/model"
	"github.com/micro/go-micro/registry/consul"
)

func main() {
	//初始化MySQL和Redis
	model.InitDb()
	model.InitRedis()

	//服务默认注册在mdns上,需要注册到consul上
	consulRegistry := consul.NewRegistry()

	// New Service
	service := micro.NewService(
		micro.Name("go.micro.srv.getArea"),
		micro.Version("latest"),
		micro.Registry(consulRegistry),
		micro.Address(":9966"),
	)

	// Initialise service
	service.Init()

	// Register Handler
	getArea.RegisterGetAreaHandler(service.Server(), new(handler.GetArea))

	// Run service
	if err := service.Run(); err != nil {
		log.Fatal(err)
	}
}
