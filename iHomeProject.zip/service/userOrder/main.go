package main

import (
	"github.com/micro/go-micro/util/log"
	"github.com/micro/go-micro"
	"iHomeProject/service/userOrder/handler"

	userOrder "iHomeProject/service/userOrder/proto/userOrder"
	"github.com/micro/go-micro/registry/consul"
	"iHomeProject/service/userOrder/model"
)

func main() {
	consulReg := consul.NewRegistry()

	// New Service
	service := micro.NewService(
		micro.Name("go.micro.srv.userOrder"),
		micro.Version("latest"),
		micro.Registry(consulReg),
		micro.Address(":5566"),
	)

	// Initialise service
	service.Init()
	model.InitDb()

	// Register Handler
	userOrder.RegisterUserOrderHandler(service.Server(), new(handler.UserOrder))

	// Run service
	if err := service.Run(); err != nil {
		log.Fatal(err)
	}
}
