package handler

import (
	"context"
	"fmt"
	userOrder "iHomeProject/service/userOrder/proto/userOrder"
	"iHomeProject/service/userOrder/model"
	"iHomeProject/web/tool"
	"strconv"
)

type UserOrder struct{}

func (e *UserOrder)CreateOrder(ctx context.Context,req *userOrder.Request,resp *userOrder.Response)error{
	//获取到相关数据，插入到数据库
	orderId,err:=model.InsertOrder(req.HouseId,req.StartDate,req.EndDate,req.UserName)
	if err != nil{
		resp.Errno = tool.RECODE_DBERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_DBERR)
		return nil
	}
	resp.Errno = tool.RECODE_OK
	resp.Errmsg = tool.RecodeText(tool.RECODE_OK)
	var orderData userOrder.OrderData
	orderData.OrderId = strconv.Itoa(orderId)

	resp.Data = &orderData
	return nil
}


func (e *UserOrder)GetOrderInfo(ctx context.Context,req *userOrder.GetReq, resp *userOrder.GetResp)error{
	respData,err := model.GetOrderInfo(req.UserName,req.Role)
	if err != nil{
		resp.Errno = tool.RECODE_DATAERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_DATAERR)
		return nil
	}
	resp.Errno = tool.RECODE_OK
	resp.Errmsg = tool.RecodeText(tool.RECODE_OK)
	var getData userOrder.GetData
	getData.Orders = respData
	resp.Data = &getData

	return nil
}

func (e *UserOrder)UpdateStatus(ctx context.Context,req *userOrder.UpdateReq,resp *userOrder.UpdateResp)error{
	//根据传入的数据,更新订单信息
	err := model.UpdateStatus(req.Action,req.Id,req.Reason)
	if err != nil{
		fmt.Println("更新订单状态错误",err)
		resp.Errno = tool.RECODE_DATAERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_DATAERR)
		return nil
	}
	resp.Errno = tool.RECODE_OK
	resp.Errmsg = tool.RecodeText(tool.RECODE_OK)

	return nil
}

func (e *UserOrder)UpdateComment(ctx context.Context,req *userOrder.CommentReq,resp *userOrder.UpdateResp)error{
	//根据传入的评论信息，更新评论状态
	err := model.UpdateComment(req.Comment,req.Id)
	if err != nil{
		fmt.Println("更新评论状态错误",err)
		resp.Errno = tool.RECODE_DATAERR
		resp.Errmsg = tool.RecodeText(tool.RECODE_DATAERR)
		return nil
	}
	resp.Errno = tool.RECODE_OK
	resp.Errmsg = tool.RecodeText(tool.RECODE_OK)

	return nil
}
